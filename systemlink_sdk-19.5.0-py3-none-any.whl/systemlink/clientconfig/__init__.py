# -*- coding: utf-8 -*-
"""
API to automatically build HTTP client configurations.
"""

from systemlink.clientconfig.configuration_manager import (
    get_configuration, get_configuration_by_id)

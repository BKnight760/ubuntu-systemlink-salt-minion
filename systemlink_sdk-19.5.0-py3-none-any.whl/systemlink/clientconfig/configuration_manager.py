# -*- coding: utf-8 -*-
"""
Provides configurations to be used in HTTP clients.
"""
import codecs
import json
import os
import os.path
from typing import Dict, Optional, Tuple

from systemlink.clientconfig.configuration import Configuration
from systemlink.messagebus.paths import get_application_data_directory

HTTP_MASTER_CONFIGURATION_ID = 'SYSTEMLINK_MASTER'
HTTP_LOCALHOST_CONFIGURATION_ID = 'SYSTEMLINK_LOCALHOST'


def get_configuration(route_name: str) -> Configuration:
    """
    Gets a generic HTTP configuration for a service.

    :param route_name: The service's route name, e.g. 'nitestmonitor'
    :type route_name: str
    :return: A configuration for the service.
    :rtype: Configuration
    """
    return get_configuration_by_id(None, route_name, True)


def get_configuration_by_id(
        configuration_id: Optional[str],
        route_name: str,
        enable_fallbacks: bool) -> Configuration:
    """
    Gets a specific HTTP configuration for a service.

    :param configuration_id: The ID of the configuration to look for,
        or None for default configurations.
    :type configuration_id: Optional[str]
    :param route_name: The service's route name.
    :type route_name: str
    :param enable_fallbacks: Whether or not to fallback to other known
        configurations if the requested configuration is not available.
    :type enable_fallbacks: bool
    :return: A configuration for the service.
    :rtype: Configuration
    """
    configurations = _read_configurations(route_name)
    if configuration_id is None:
        if enable_fallbacks:
            fallback_configuration = _fallback(configurations)
            if fallback_configuration is None:
                raise ValueError('No SystemLink configurations available.')
            return fallback_configuration
        raise ValueError('configuration_id cannot be null if enable_fallbacks is also false.')

    normalized_id = configuration_id.upper()
    selected_configuration = configurations.get(normalized_id)
    if selected_configuration is not None:
        return selected_configuration

    if not enable_fallbacks:
        raise ValueError('Configuration with ID {0} was not found.'.format(normalized_id))
    fallback_configuration = _fallback(configurations)
    if fallback_configuration is None:
        raise ValueError(
            'Configuration with ID {0} was not found and no fallback configurations were available.'
            .format(normalized_id))
    return fallback_configuration


def _fallback(configurations: Dict[str, Configuration]) -> Optional[Configuration]:
    """
    Performs fallback logic if configurations cannot be found.

    :param configurations: The dictionary of discovered configurations.
    :type configurations: Dict[str, Configuration]
    :return: The fallback configuration, or None if the fallback was not successful.
    :rtype: Optional[Configuration]
    """
    master_configuration = configurations.get(HTTP_MASTER_CONFIGURATION_ID)
    if master_configuration is not None:
        return master_configuration
    localhost_configuration = configurations.get(HTTP_LOCALHOST_CONFIGURATION_ID)
    return localhost_configuration


def _read_configurations(route_name: str) -> Dict[str, Configuration]:
    """
    Discovers and reads HTTP configurations.

    :param route_name: The route name to use when generating service configurations.
    :type route_name: str
    :return: A dict mapping each discovered configuration ID to its corresponding configuration.
    :rtype: Dict[str, Configuration]
    """
    configurations = {}
    configurations_path = _get_http_configurations_directory()
    if not os.path.isdir(configurations_path):
        return configurations

    json_files = [os.path.join(configurations_path, name)
                  for name in os.listdir(configurations_path)
                  if name.endswith('.json')
                  and os.path.isfile(os.path.join(configurations_path, name))]
    for file in json_files:
        configuration_id, configuration = _read_config_file(file, route_name)
        if configuration_id is not None:
            configurations[configuration_id] = configuration
    return configurations


def _read_config_file(path: str, route_name: str) -> Tuple[str, Configuration]:
    """
    Generates a configuration from a configuration file.

    :param path: The path of the configuration file.
    :type path: str
    :param route_name: The route name to use when generating a service configuration.
    :type route_name: str
    :return: A 2-tuple containing the configuration ID and the configuration,
        or (None, None) if the configuration could not be read.
    :rtype: Tuple[str, Configuration]
    """
    if not os.path.isfile(path):
        return None, None

    with codecs.open(path, 'r') as file:
        configuration_file = json.loads(file.read())
    configuration_id = configuration_file.get('Id')
    if configuration_id is not None:
        cert_path = configuration_file.get('CertPath')
        if cert_path is not None:
            cert_path = _get_certificate_path(configuration_file['CertPath'])
        configuration_id = configuration_file['Id'].upper()
        configuration = Configuration(configuration_file, route_name, cert_path)
        return configuration_id, configuration
    return None, None


def _get_http_configurations_directory() -> str:
    """
    Gets the directory where HTTP configurations are stored.
    :return: The path to the HTTP configurations directory.
    :rtype: str
    """
    path = os.path.join(
        get_application_data_directory(),
        'HttpConfigurations'
    )
    return path


def _get_certificate_path(cert_path: str) -> str:
    """
    Gets the full path to a certificate.

    :param cert_path: The configured certificate path.
    :type cert_path: str
    :return: The absolute path of the certificate.
    :rtype: str
    """
    if os.path.isabs(cert_path):
        return cert_path
    path = os.path.join(
        get_application_data_directory(),
        'Certificates',
        cert_path
    )
    return path

# coding: utf-8
"""
A HTTP python client configuration which is created from an on-disk HttpConfiguration.
"""

from __future__ import absolute_import

from typing import Any, Dict, List, Optional

import http.client
import logging
import multiprocessing
import sys
import urllib.parse
import urllib3


class Configuration(object):  # pylint: disable=too-many-instance-attributes
    """
    Represents a HTTP configuration for a client API.
    """

    def __init__(self, configuration_dict: Dict[str, Any],
                 route_name: str,
                 cert_path: Optional[str]):
        """
        :param configuration_dict: The configuration dictionary.
        :type configuration_dict: Dict[str, Any]
        :param route_name: The name of the route that this configuration
            represents, e.g. 'nitestmonitor'
        :type route_name: str
        :param cert_path: The path to the SSL certificate, or None.
        :type cert_path: Optional[str]
        """
        # Default Base url
        configured_uri = configuration_dict.get('Uri')
        self.host = urllib.parse.urljoin(configured_uri, route_name)
        # Temp file folder for downloading files
        self.temp_folder_path = None

        # Authentication Settings
        # dict to store API key(s)
        configured_api_key = configuration_dict.get('ApiKey')
        if configured_api_key is None:
            self.api_key = {}
        else:
            self.api_key = {
                'x-ni-api-key': configured_api_key
            }
        # dict to store API prefix (e.g. Bearer)
        self.api_key_prefix = {}
        # Username for HTTP basic authentication
        self.username = ''
        # Password for HTTP basic authentication
        self.password = ''
        # Logging Settings
        self.logger = {}
        self.logger['package_logger'] =\
            logging.getLogger('systemlink.clients.{0}'.format(route_name))
        self.logger['urllib3_logger'] = logging.getLogger('urllib3')
        # Log format
        self.logger_format = '%(asctime)s %(levelname)s %(message)s'
        # Log stream handler
        self.logger_stream_handler = None
        # Log file handler
        self.logger_file_handler = None
        # Debug file location
        self.logger_file = None
        # Debug switch
        self.debug = False

        # SSL/TLS verification
        # Set this to false to skip verifying SSL certificate when calling API
        # from https server.
        self.verify_ssl = True
        # Set this to customize the certificate file to verify the peer.
        self.ssl_ca_cert = cert_path
        # client certificate file
        self.cert_file = None
        # client key file
        self.key_file = None
        # Set this to True/False to enable/disable SSL hostname verification.
        self.assert_hostname = None

        # urllib3 connection pool's maximum number of connections saved
        # per pool. urllib3 uses 1 connection as default value, but this is
        # not the best value when you are making a lot of possibly parallel
        # requests to the same host, which is often the case here.
        # cpu_count * 5 is used as default value to increase performance.
        self.connection_pool_maxsize = multiprocessing.cpu_count() * 5

        # Proxy URL
        self.proxy = None
        # Proxy headers
        self.proxy_headers = None
        # Safe chars for path_param
        self.safe_chars_for_path_param = ''
        # Adding retries to override urllib3 default value 3
        self.retries = None

    @property
    def logger_file(self) -> Optional[str]:
        """
        The logger file.

        If the logger_file is None, then add stream handler and remove file
        handler. Otherwise, add file handler and remove stream handler.

        :return: The logger file, or None if none exists.
        :rtype: Optional[str]
        """
        return self.__logger_file

    @logger_file.setter
    def logger_file(self, value: Optional[str]) -> None:
        """
        The logger file.

        If the logger_file is None, then add stream handler and remove file
        handler. Otherwise, add file handler and remove stream handler.

        :param value: The logger_file path.
        :type value: Optional[str]
        """
        self.__logger_file = value  # pylint: disable=attribute-defined-outside-init
        if self.__logger_file:
            # If set logging file,
            # then add file handler and remove stream handler.
            self.logger_file_handler = logging.FileHandler(self.__logger_file)
            self.logger_file_handler.setFormatter(self.logger_formatter)
            for _, logger in self.logger.items():
                logger.addHandler(self.logger_file_handler)

    @property
    def debug(self) -> bool:
        """
        Gets the debug status

        :return: The debug status.
        :rtype: bool
        """
        return self.__debug

    @debug.setter
    def debug(self, value: bool) -> None:
        """
        Sets the debug status

        :param value: The debug status, True or False.
        :type value: bool
        """
        self.__debug = value  # pylint: disable=attribute-defined-outside-init
        if self.__debug:
            # if debug status is True, turn on debug logging
            for _, logger in self.logger.items():
                logger.setLevel(logging.DEBUG)
            # turn on httplib debug
            http.client.HTTPConnection.debuglevel = 1
        else:
            # if debug status is False, turn off debug logging,
            # setting log level to default `logging.WARNING`
            for _, logger in self.logger.items():
                logger.setLevel(logging.WARNING)
            # turn off httplib debug
            http.client.HTTPConnection.debuglevel = 0

    @property
    def logger_format(self) -> str:
        """
        Gets the logger format string used by the client logger.

        :return: The logger format.
        :rtype: str
        """
        return self.__logger_format

    @logger_format.setter
    def logger_format(self, value: str) -> None:
        """
        Sets the client logger's format string.

        :param value: The format string.
        :type value: str
        """
        self.__logger_format = value  # pylint: disable=attribute-defined-outside-init
        self.logger_formatter = logging.Formatter(self.__logger_format)  # pylint: disable=attribute-defined-outside-init

    # pylint: disable=inconsistent-return-statements, no-else-return
    def get_api_key_with_prefix(self, identifier: str) -> Optional[str]:
        """
        Gets an API key (with prefix if set).

        :param identifier: The identifier of the API key to find.
        :type identififer: str
        :return: The fully-qualified API key.
        :rtype: Optional[str]
        """
        if (self.api_key.get(identifier) and
                self.api_key_prefix.get(identifier)):
            return self.api_key_prefix[identifier] + ' ' + self.api_key[identifier]
        if self.api_key.get(identifier):
            return self.api_key[identifier]

    def get_basic_auth_token(self) -> Optional[str]:
        """
        Gets the HTTP basic authentication header.

        :return: The token for basic HTTP authentication.
        :rtype: Optional[str]
        """
        return urllib3.util.make_headers(
            basic_auth=self.username + ':' + self.password
        ).get('authorization')

    def auth_settings(self) -> Dict[str, Any]:
        """
        Gets the auth settings dict for the API client.

        :return: The auth settings information dict.
        :rtype: Dict[str, Any]
        """
        return {
            'apiKeyAuth': {
                'type': 'api_key',
                'in': 'header',
                'key': 'x-ni-api-key',
                'value': self.get_api_key_with_prefix('x-ni-api-key')
            },
            'cookieAuth': {
                'type': 'api_key',
                'in': 'header',
                'key': 'Cookie',
                'value': self.get_api_key_with_prefix('Cookie')
            },
        }

    def to_debug_report(self) -> str:  # pylint: disable=no-self-use
        """
        Gets the essential information for debugging.

        :return: The report for debugging.
        :rtype: str
        """
        return (
            'Python SDK Debug Report:\n'
            'OS: {env}\n'
            'Python Version: {pyversion}\n'
            'Version of the API: 1\n'
            'SDK Package Version: 1.0.0'
            .format(env=sys.platform, pyversion=sys.version)
        )

    def get_host_settings(self) -> List[Dict[str, Any]]:
        """
        Gets a list of host settings

        :return: A list of host settings
        :rtype: List[Dict[str, Any]]
        """
        return [
            {
                'url': self.host,
                'description': "No description provided",
            }
        ]

    def get_host_from_settings(self, index: int, variables: Optional[Dict[str, Any]] = None) -> str:
        """
        Gets host URL based on the index and variables

        :param index: array index of the host settings
        :type index: int
        :param variables: hash of variable and the corresponding value
        :type variables: Dict[str, Any]
        :return: URL based on host settings
        :rtype: str
        """
        servers = self.get_host_settings()

        # check array index out of bound
        if index < 0 or index >= len(servers):
            raise ValueError(
                'Invalid index {} when selecting the host settings. Must be less than {}'
                .format(index, len(servers)))

        server = servers[index]
        url = server['url']

        variables = variables if variables else {}

        # go through variable and assign a value
        for variable_name in server['variables']:
            if variable_name in variables:
                if variables[variable_name] in server['variables'][
                        variable_name]['enum_values']:
                    url = url.replace("{" + variable_name + "}",
                                      variables[variable_name])
                else:
                    raise ValueError(
                        'The variable `{}` in the host URL has invalid value {}. Must be {}.'
                        .format(
                            variable_name, variables[variable_name],
                            server['variables'][variable_name]['enum_values']))
            else:
                # use default value
                url = url.replace(
                    '{' + variable_name + '}',
                    server['variables'][variable_name]['default_value'])

        return url

# -*- coding: utf-8 -*-
"""
API to interact with the Skyline Asset Management Service.
"""
from __future__ import absolute_import

# Import python libs
import datetime
import logging

# Import local libs
# pylint: disable=import-error
from systemlink.messagebus.amqp_connection_manager import AmqpConnectionManager
from systemlink.messagebus.exceptions import SystemLinkException
from systemlink.messagebus.message_service import MessageService
from systemlink.messagebus.message_service_builder import MessageServiceBuilder
from . import messages as assetmgmt_messages  # pylint: disable=no-name-in-module,import-self
# pylint: enable=import-error

# Set up logging
LOGGER = logging.getLogger(__name__)


class AssetManagementClient():
    """
    Class to publicly access the Asset Management Service API.
    """

    def __init__(self,  # pylint: disable=too-many-arguments
                 message_service=None,
                 service_name='AssetManagementClient',
                 connection_config=None,
                 connection_timeout=5,
                 auto_reconnect=True):
        """
        :param message_service: An instance of the message
            service to use or ``None`` to allow this object to create and own
            the message service.
        :type message_service: systemlink.messagebus.message_service.MessageService or None
        :param service_name: If `message_service` is ``None`` and therefore
            this object creates and owns the message service, the name to
            use for this message service. Try to pick a unique name for
            your client.
        :type service_name: str or None
        :param connection_config: If ``message_service`` is ``None``,
            the configuration to use for this message service. If this
            is ``None``, will use the default configuration.
        :type connection_config: systemlink.messagebus.amqp_configuration.AmqpConfiguration or None
        :param connection_timeout: Timeout, in seconds, to use
            when trying to connect to the message broker.
        :type connection_timeout: float or int
        """
        self._closing = False
        self._own_message_service = False
        self._connection_manager = None
        if message_service is not None:
            self._message_service = message_service
        else:
            self._connection_manager = AmqpConnectionManager(
                config=connection_config)
            self._connection_manager.connection_timeout = connection_timeout
            self._connection_manager.auto_reconnect = auto_reconnect
            message_service_builder = MessageServiceBuilder(service_name)
            message_service_builder.connection_manager = self._connection_manager
            self._message_service = MessageService(message_service_builder)
            self._own_message_service = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __del__(self):
        self.close()

    def close(self):
        """
        Close the AssetManagementClient and all associated resources.
        """
        if self._closing:
            return
        self._closing = True
        if self._own_message_service:
            self._message_service.close()
            self._connection_manager.close()

    def query_assets(self,  # pylint: disable=too-many-arguments
                     ids=None,
                     skip=None,
                     take=None,
                     order_by=None,
                     order_by_descending=None,
                     filter_=None):
        """
        Query the data for multiple assets.

        :param ids: List of asset identifiers to restrict the search to.
        :type ids: list(string)
        :param skip: Number of results to skip.
        :type skip: int
        :param take: Maximum number of results to return.
        :type take: int
        :param order_by: A field on the asset data to order by.
        :type order_by: string
        :param order_by_descending: Whether or not the results should be
            returned in descending order.
        :type order_by_descending: bool
        :param filter_: Specifies the filter criteria for assets.
            Consists of a string of queries composed using AND/OR operators.
            String values and date strings need to be enclosed in double quotes.
            Parenthesis can be used around filtes to better define the order of operations.
            Filter syntax: '[property name][operator][operand] and
                [property name][operator][operand]'

            Operators:

            Equals operator '='.
                Example: 'x = y'
            Not equal operator '!='.
                Example: 'x != y'
            Greater than operator '>'.
                Example: 'x > y'
            Greater than or equal operator '>='.
                Example: 'x >= y'
            Less than operator '<'.
                Example: 'x < y'
            Less than or equal operator '<='.
                Example: 'x <= y'
            Logical AND operator 'and'.
                Example: 'x and y'
            Logical OR operator 'or'.
                Example: 'x or y'
            Contains operator '.Contains()', used to check whether a
                string contains another string.
                Example: 'x.Contains(y)'
            Not Contains operator '!.Contains()', used to check whether
                a string does not contain another string.
                Example: '!x.Contains(y)'
            Valid asset properties that can be used in the filter:

            AssetIdentifier: String representing the unique identifier of an asset.
            AssetClass: String enumeration representing the class of an asset.
                Possible values are: UNDEFINED, DISCOVERED, ASSET, DUT, FIXTURE.
            SerialNumber: String representing the serial number of an asset.
            ModelName: String representing the model name of an asset.
            ModelNumber: Unsigned integer representing the model number of an asset.
            VendorName: String representing the vendor name of an asset.
            VendorNumber: Unsigned integer representing the vendor number of an asset.
            AssetName: String representing the asset name.
            FirmwareVersion: String representing the firmware version of an asset.
            HardwareVersion: String representing the hardware version of an asset.
            BusType: String enumeration representing the bus type of an asset.
                Possible values are:
                    BUILT_IN_SYSTEM
                    PCI_PXI
                    USB
                    GPIB
                    VXI
                    SERIAL
                    TCP_IP
                    CRIO
                    SCXI
                    CDAQ
                    SWITCH_BLOCK
                    SCC
                    FIRE_WIRE
                    ACCESSORY
                    CAN
                    SWITCH_BLOCK_DEVICE
            IsNIAsset: Boolean flag specifying whether the asset is an
                NI asset or a 3rd party asset.
            Keywords: Collection of string values representing asset metadata keywords.
                Example: 'Keywords=["keyword1", "keyword2"]'.
            Properties: Collection of key-value pairs, each key-value
                pair representing an asset metadata property.
                Example: 'Properties=["key1:value1", "key2:value2"]'.
            Location.MinionId: String representing the identifier of
                the minion in which the asset is located in.
            Location.SystemName: String representing the name of the
                system that the asset is located in.
            Location.SlotNumber: Unsigned integer representing the slot
                number the asset is located in.
            Location.AssetState.SystemConnection: String enumeration representing the
                connection state of the system the asset is currently located in.
                Possible values are:
                    APPROVED
                    DISCONNECTED
                    CONNECTED_UPDATE_PENDING
                    CONNECTED_UPDATE_SUCCESSFUL
                    CONNECTED_UPDATE_FAILED
                    UNSUPPORTED
                    ACTIVATED
            Location.AssetState.AssetPresence: String enumeration representing the
                present status of an asset in a system.
                Possible values are:
                    INITIALIZING
                    UNKNOWN
                    NOT_PRESENT
                    PRESENT
            SupportsSelfCalibration: Boolean flag specifying whether
                the asset supports self calibration.
            SelfCalibration.CalibrationDate: ISO-8601 formatted timestamp string specifying
                the last date the asset was self-calibrated.
                Example: "2018-05-20T00:00:00Z"
            SupportsExternalCalibration: Boolean flag specifying
                whether the asset supports external calibration.
            ExternalCalibration.CalibrationDate: ISO-8601 formatted timestamp string specifying
                the last date the asset was externally-calibrated.
                Example: "2018-05-20T00:00:00Z"
            ExternalCalibration.NextRecommendedDate: ISO-8601 formatted timestamp string specifying
                the recommended date for the next external calibration.
                Example: "2018-05-20T00:00:00Z"
            ExternalCalibration.RecommendedInterval: Integer
                representing the manufacturer-recommended calibration
                interval, in months.
            ExternalCalibration.Comments: String representing any external calibration comments.
            ExternalCalibration.IsLimited: Boolean flag specifying
                whether the last external calibration was a limited
                calibration.
            ExternalCalibration.Operator.DisplayName: String representing the name of the operator
                which performed an external calibration on a 3rd party asset.
        :type filter_: string
        :return: Results that matched the query and the number of returned assets.
        :rtype: tuple(list(systemlink.assetmngrclient.messages.AssetModel), int)
        """
        request = assetmgmt_messages.AssetPerformanceManagementQueryAssetsV2Request(
            ids,
            skip,
            take,
            order_by,
            order_by_descending,
            filter_)
        generic_message = self._message_service.publish_synchronous_message(request)
        response = self._generic_to_specific_message(
            assetmgmt_messages.AssetPerformanceManagementQueryAssetsV2Response.from_message,
            generic_message, False
        )
        response = assetmgmt_messages.AssetPerformanceManagementQueryAssetsV2Response.from_message(
            generic_message)
        LOGGER.debug('message = %s', response)
        return response

    def query_assets_availability(
            self,
            ids,
            intervals):
        """
        Query the availability of multiple assets during multiple date time intervals.

        :param ids: List of asset identifiers for which the availability is queried.
        :type ids: list(string).
        :param intervals: List of dictionaries for the intervals to
            compute the availability in. The intervals are specified
            by the 'start_date' and 'end_date' keys.
        :type intervals: list(dict(string, datetime))
        :return: List of availability information for each asset during every date time interval.
                 The availability information for each asset and date time interval pair is returned
                 as a list of availability percentages for the systems it was active in. A query
                 error which contains errors caused by invalid ids, nonexistent ids, or invalid
                 date time intervals passed as arguments is also included.
        :rtype: tuple(list(systemlink.assetmngtclient.messages.AssetWithAvailabilityModel),
                systemlink.assetmngtclient.messages.ErrorModel)
        """
        date_interval_models = []
        for interval in intervals:
            date_interval_model = assetmgmt_messages.DateIntervalModel(
                interval['start_date'], interval['end_date'])
            date_interval_models.append(date_interval_model)
        request = assetmgmt_messages.AssetPerformanceManagementQueryAssetsAvailabilityRequest(
            ids,
            date_interval_models
        )
        generic_message = self._message_service.publish_synchronous_message(request)
        response = self._generic_to_specific_message(
            assetmgmt_messages.AssetPerformanceManagementQueryAssetsAvailabilityResponse.from_message,  # pylint: disable=line-too-long
            generic_message, True
        )
        LOGGER.debug('message = %s', response)
        return response

    @staticmethod
    def _generic_to_specific_message(conversion_function, generic_message, allow_error):
        """
        Convert a generic message to a specific message. The message
        type of the specific message is determined by the
        ``conversion_function`` argument.

        :param conversion_function: A callable that takes the generic
            message as the only input argument and returns an instance
            of a specific message type (which is a derived class of
            :class:`systemlink.messagebus.message_base.MessageBase`).
        :type conversion_function: callable
        :param generic_message: The generic message to convert from.
        :type generic_message:
            systemlink.messagebus.generic_message.GenericMessage or
            None
        :param allow_error: If ``True``, will still attempt to
            deserialize to a specific message object even if an error
            is set in the generic message. If ``False``, will always
            raise a :class:`SystemLinkException` when an error is set
            in the generic message.
        :type allow_error: bool
        :return: An instance of the specific message type that is the
            output of the ``convertsion_function`` callable. This is
            a derived class of
            :class:`systemlink.messagebus.message_base.MessageBase`.
        :rtype: systemlink.messagebus.message_base.MessageBase
        :raises SystemLinkException: if a timeout occurred (the
            ``generic_message`` argument is ``None``) or if there is
            an error specified in the generic message and the
            generic message is not convertible via the
            ``conversion_function`` argument or ``allow_error`` is
            ``False``.
        """
        if generic_message is None:
            raise SystemLinkException.from_name('Skyline.RequestTimedOut')
        if generic_message.has_error():
            if not allow_error or not generic_message.body_bytes:
                raise SystemLinkException(error=generic_message.error)
            try:
                return conversion_function(generic_message)
            except Exception:  # pylint: disable=broad-except
                raise SystemLinkException(error=generic_message.error)
        return conversion_function(generic_message)
